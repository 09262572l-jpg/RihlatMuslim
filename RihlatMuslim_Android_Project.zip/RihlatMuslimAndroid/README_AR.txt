رحلة مسلم - مشروع Android

هذه النسخة تحوّل لعبة HTML الحالية إلى تطبيق Android أصلي عبر WebView، مع تشغيل اللعبة محليًا بدون خادم.

محتويات المشروع:
- app/src/main/assets/index.html : اللعبة
- app/src/main/assets/questions.json : بنك الأسئلة
- MainActivity.java : مشغل التطبيق
- AndroidManifest.xml : إعداد التطبيق

اسم التطبيق: رحلة مسلم
Package: com.rihlat.muslim
Version: 1.0

لإنشاء APK/AAB: افتح مجلد المشروع في Android Studio ثم Build > Build APK(s) أو Generate Signed App Bundle.

ملاحظة: بيئة العمل الحالية لا تحتوي Android SDK/Build Tools، لذلك تم تجهيز مشروع Android كامل المصدر بدل APK مبني مباشرة.
